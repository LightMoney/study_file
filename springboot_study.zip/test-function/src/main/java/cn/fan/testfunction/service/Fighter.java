package cn.fan.testfunction.service;

public interface Fighter {
    void fight();
}