package cn.fan.testfunction.model;

public class User {
}
