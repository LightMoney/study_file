package cn.fan.redis_publish_subscriber;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisPublishSubscriberApplicationTests {

    @Test
    void contextLoads() {
    }

}
