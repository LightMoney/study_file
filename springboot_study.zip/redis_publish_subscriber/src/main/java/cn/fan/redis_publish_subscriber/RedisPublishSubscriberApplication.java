package cn.fan.redis_publish_subscriber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisPublishSubscriberApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisPublishSubscriberApplication.class, args);
    }

}
