package cn.fan.poitl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoiTlApplication {

    public static void main(String[] args) {
        SpringApplication.run(PoiTlApplication.class, args);
    }

}
