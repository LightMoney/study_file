package cn.fan.devtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevtoolApplicationTests {

    @Test
    void contextLoads() {
    }

}
