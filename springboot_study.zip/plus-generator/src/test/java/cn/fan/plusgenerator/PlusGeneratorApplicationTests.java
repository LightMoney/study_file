package cn.fan.plusgenerator;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlusGeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
