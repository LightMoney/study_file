package cn.fan.mybatisplus.service;

import cn.fan.mybatisplus.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserService extends IService<User> {
    //写一些自定的通用方法
}
