package cn.fan.springbootrabbitmqmqtt;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqMqttApplicationTests {

    @Test
    void contextLoads() {
    }

}
