package cn.fan.hbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHbaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootHbaseApplication.class, args);
    }

}
