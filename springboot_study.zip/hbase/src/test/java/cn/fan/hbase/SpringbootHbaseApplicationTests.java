package cn.fan.hbase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHbaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
