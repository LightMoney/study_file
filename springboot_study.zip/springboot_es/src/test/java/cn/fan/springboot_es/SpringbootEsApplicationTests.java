package cn.fan.springboot_es;




import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEsApplicationTests {

    @Test
    void contextLoads() {
    }

}
