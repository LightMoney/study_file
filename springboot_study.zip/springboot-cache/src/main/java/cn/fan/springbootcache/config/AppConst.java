package cn.fan.springbootcache.config;

public class AppConst {
    public final static String BASE_PACKAGE_NAME = "cn.fan.springbootcache";
    public final static long CACHE_MAXIMUM_SIZE = 1024;
    public final static long CACHE_MINUTE = 600000;//单位毫秒

    public final static String CACHE_VERSION_KEY = "first";

}
