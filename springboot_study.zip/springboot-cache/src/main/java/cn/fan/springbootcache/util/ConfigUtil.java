package cn.fan.springbootcache.util;

import lombok.Data;


public class ConfigUtil {


    public static String getConfigVal(String val) {
        return val;
    }
}
