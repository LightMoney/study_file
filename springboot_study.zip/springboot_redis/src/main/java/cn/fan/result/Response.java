package cn.fan.result;

public interface Response {
    public static final boolean SUCCESS = true;
    public static final boolean FAlSE = false;
    public static final int SUCCESS_CODE = 10000;
    public static final int FAlSE_CODE = 20000;
}