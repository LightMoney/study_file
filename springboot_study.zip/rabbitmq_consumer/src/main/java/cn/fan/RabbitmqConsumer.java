package cn.fan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqConsumer {

    public static void main(String[] args) {
        SpringApplication.run(RabbitmqConsumer.class, args);
    }

}
