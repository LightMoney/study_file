package cn.fan.domain.vaild;

/**
 * 安全验证常用类
 */
public  class SecurityConstants {

    public static final int SMS_EXPIRE_SECOND = 1800;
}
