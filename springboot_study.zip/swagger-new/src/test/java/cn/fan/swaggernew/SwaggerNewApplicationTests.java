package cn.fan.swaggernew;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerNewApplicationTests {

    @Test
    void contextLoads() {
    }

}
