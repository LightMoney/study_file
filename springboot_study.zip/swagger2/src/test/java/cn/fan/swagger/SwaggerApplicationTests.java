package cn.fan.swagger;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerApplicationTests {

    @Test
    void contextLoads() {
    }

}
