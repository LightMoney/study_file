package cn.fan.swagger2.interf;

/**
 * 管理版本号的接口
 */
public interface ApiVersionConstant {
    String FAP_APP100 = "app1.0.0";
    String FAP_APP101 = "app1.0.1";
    String FAP_APP102 = "app1.0.2";
}
