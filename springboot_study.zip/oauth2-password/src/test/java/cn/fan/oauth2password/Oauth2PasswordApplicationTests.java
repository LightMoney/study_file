package cn.fan.oauth2password;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2PasswordApplicationTests {

    @Test
    void contextLoads() {
    }

}
