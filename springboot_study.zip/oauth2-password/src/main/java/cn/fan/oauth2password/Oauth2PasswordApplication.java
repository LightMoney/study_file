package cn.fan.oauth2password;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2PasswordApplication {

    public static void main(String[] args) {
        SpringApplication.run(Oauth2PasswordApplication.class, args);
    }

}
